//
//  UserProfile.swift
//  Swing-Forge-Settings
//
//  Created by Julian Bryant on 1/20/16.
//  Copyright © 2016 TMConsult. All rights reserved.
//

import Foundation
import CoreData


class UserProfile: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
