//
//  UtilityMethods.swift
//  Swing-Forge-Settings
//
//  Created by Julian Bryant on 1/10/16.
//  Copyright © 2016 TMConsult. All rights reserved.
//

import UIKit

class UtilityMethods: NSObject {
    class func showAlertInView(title:String, message:String, presentingViewController:UIViewController?){
        let alert = UIAlertController(title: title, message:message, preferredStyle: .Alert)
        alert.addAction(UIAlertAction(title: "OK", style: .Default) { _ in })
        //self.presentViewController(alert, animated: true){}
        
        if let receivedViewController = presentingViewController {
            receivedViewController.presentViewController(alert, animated: false, completion: nil)
        } else {
            let rootVC = UIApplication.sharedApplication().keyWindow?.rootViewController
            rootVC?.presentViewController(alert, animated: true){}
        }
    }
}
