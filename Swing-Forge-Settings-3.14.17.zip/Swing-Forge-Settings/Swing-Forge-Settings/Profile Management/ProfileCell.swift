//
//  ProfileCell.swift
//  Swing-Forge-Settings
//
//  Created by Julian Bryant on 1/14/16.
//  Copyright © 2016 TMConsult. All rights reserved.
//

import UIKit

class ProfileCell: UITableViewCell {
    
    @IBOutlet var profileNameLabel:UILabel!
    @IBOutlet var loadProfileBtn:UIButton!
    
}
