//
//  AppConstants.swift
//  Swing-Forge-Settings
//
//  Created by Julian Bryant on 1/14/16.
//  Copyright © 2016 TMConsult. All rights reserved.
//

import Foundation

let kUSERDEFAULT_PeripheralID:String = "peripheralID"
let kUSERDEFAULT_PeripheralName:String = "peripheralName"

